Description:
A top-down space shooter game controlled by red color detection with opencv, hence the name CV Shooter. 
Run the project by running __init__.py as a file (ctrl+shift+e).
Library used: OpenCV + imutils and pygame on Python 3.6!!!
do pip install imutils
A webcam is required to use opencv.
ShortCut command:
Arrow keys can move the character on top of opencv
H to heal health
D to damage self
T in the main game: increase Exp, T in challenge: firepower becomes level 3
E in main game to add an enemy to the group
S to skip to the boss
Numbers 1-4 to skip to level 1-4
